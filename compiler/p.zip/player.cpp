#include <iostream>

int main() {
	std::cout << "Hi there." << std::endl;
}
